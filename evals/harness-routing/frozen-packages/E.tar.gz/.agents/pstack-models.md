# Project model choices

## codex

default: gpt-6.1-sol@high
feature: gpt-6.1-sol@high
hardest tasks: gpt-6.1-sol@xhigh
trail reviewer: gpt-6-astra@high
